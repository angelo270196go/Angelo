﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// Il modello di elemento per la pagina vuota è documentato all'indirizzo http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x410

namespace Calendario_Lunare_Giardinaggio
{
    /// <summary>
    /// Pagina vuota che può essere utilizzata autonomamente oppure esplorata all'interno di un frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            Leggi();
        }
        public async void Leggi()
        {
            string Titolo = "Calendario Lunare Giardinaggio";
            TITLEBOX.Text = Convert.ToString(Titolo);
            int Month = DateTime.Now.Month;
            List<Contenitutto> L = new List<Contenitutto>();
            Contenitutto C = new Contenitutto();
            #region //ContieniIF
            if (Month == 01)
            {
                string testo = "";
                string M = "Questo è il mese di Gennaio";
                MESEBOX.Text = Convert.ToString(M);
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.gennaiopath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);

                }
            }
            else if (Month == 02)
            {
                string testo = "";
                string M = "Questo è il mese di Febbraio";
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.febbraiopath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);

                }
                MESEBOX.Text = Convert.ToString(M);
            }
            else if (Month == 03)
            {
                string testo = "";
                string M = "Questo è il mese di Marzo";
                MESEBOX.Text = Convert.ToString(M);
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.marzopath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);
                }
            }
            else if (Month == 04)
            {
                string testo = "";
                string M = "Questo è il mese di Aprile";
                MESEBOX.Text = Convert.ToString(M);
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.aprilepath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);

                }
            }
            else if (Month == 05)
            {
                string testo = "";
                string M = "Questo è il mese di Maggio";
                MESEBOX.Text = Convert.ToString(M);
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.maggiopath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);

                }
            }
            else if (Month == 06)
            {
                string testo = "";
                string M = "Questo è il mese di Giugno";
                MESEBOX.Text = Convert.ToString(M);
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.giugnopath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);

                }
            }
            else if (Month == 07)
            {
                string testo = "";
                string M = "Questo è il mese di Luglio";
                MESEBOX.Text = Convert.ToString(M);
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.lugliopath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);

                }
            }
            else if (Month == 08)
            {
                string testo = "";
                string M = "Questo è il mese di Agosto";
                MESEBOX.Text = Convert.ToString(M);
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.agostopath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);

                }
            }
            else if (Month == 09)
            {
                string testo = "";
                string M = "Questo è il mese di Settembre";
                MESEBOX.Text = Convert.ToString(M);
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.settembrepath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);

                }
            }
            else if (Month == 10)
            {
                string testo = "";
                string M = "Questo è il mese di Ottobre";
                MESEBOX.Text = Convert.ToString(M);
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.ottobrepath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);

                }
            }
            else if (Month == 11)
            {
                string testo = "";
                string M = "Questo è il mese di Novembre";
                MESEBOX.Text = Convert.ToString(M);
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.novembrepath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);

                }
            }
            else if (Month == 12)
            {
                string testo = "";
                string M = "Questo è il mese di Dicembre";
                MESEBOX.Text = Convert.ToString(M);
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///" + C.dicembrepath));
                using (StreamReader rd = new StreamReader(await file.OpenStreamForReadAsync()))
                {
                    testo = rd.ReadToEnd();
                    Content.Items.Add(testo);

                }
            }
            #endregion
        }


        private void Page_SizeChanged(object sender, SizeChangedEventArgs e)
        {

        }
    }
}
