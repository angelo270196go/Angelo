﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calendario_Lunare_Giardinaggio
{
    public class Contenitutto
    {
        public string gennaiopath = "Months/Gennaio.txt";
        public string febbraiopath = "Months/Febbraio.txt";
        public string marzopath = "Months/Marzo.txt";
        public string aprilepath = "Months/Aprile.txt";
        public string maggiopath = "Months/Maggio.txt";
        public string giugnopath = "Months/Giugno.txt";
        public string lugliopath = "Months/Luglio.txt";
        public string agostopath = "Months/Agosto.txt";
        public string settembrepath = "Months/Settembre.txt";
        public string ottobrepath = "Months/Ottobre.txt";
        public string novembrepath = "Months/Novembre.txt";
        public string dicembrepath = "Months/Dicembre.txt";

        public Contenitutto()
        {

        }
    }
}
